package component;

import process.ProcessState;
import process.pcb.ProcessControlBlock;
import structure.GeneralQueue;
import structure.Iterator;
import structure.Queue;

public class MainMemory {
    private Queue<ProcessControlBlock> readyQueue = new GeneralQueue<>(3);

    public Queue<ProcessControlBlock> getReadyQueue() {
        return readyQueue;
    }

    public void addProcessControlBlock(ProcessControlBlock pcb) {
        readyQueue.enqueue(pcb);
        pcb.setProcessState(ProcessState.READY);
    }

    public ProcessControlBlock removeProcessControlBlock() {
        return readyQueue.dequeue();
    }

    public void removeProcess(ProcessControlBlock pcb) {
        readyQueue.remove(pcb);
    }

    public boolean contains(ProcessControlBlock pcb) {
        return readyQueue.contains(pcb);
    }

    public String getInfo() {
        if (readyQueue.isEmpty()) {
            return "Ready Queue is Empty!";
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Ready Queue: head -> {");
        Iterator<ProcessControlBlock> iterator = readyQueue.iterator();
        while (iterator.hasNext()) {
            stringBuilder.append(iterator.next().getProcess().getInfo());
            stringBuilder.append(", ");
        }
        stringBuilder.delete(stringBuilder.length() - 2, stringBuilder.length());
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}
