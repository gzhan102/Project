package component;

import app.OperatingSystemApplication;
import process.Process;
import process.ProcessState;
import process.pcb.ProcessControlBlock;
import scheduler.LongTermScheduler;
import scheduler.ShortTermScheduler;

import java.util.Random;

public class CPU implements Runnable {
    private ProcessControlBlock pcb;
    private Random random = new Random();
    private final int maxComputingStep = 2;
    private ShortTermScheduler shortTermScheduler = new ShortTermScheduler();
    private LongTermScheduler longTermScheduler = new LongTermScheduler();

    public void setPcb(ProcessControlBlock pcb) {
        this.pcb = pcb;
    }

    public ProcessControlBlock getPcb() {
        return pcb;
    }

    public void process() {
        if (pcb != null) {
            Process process = pcb.getProcess();
            System.out.println(process.getInfo() + " is running on CPU!");
            boolean ioFinished = process.getIOFinished();
            boolean computingFinished = process.getComputingFinished();
            int flag = random.nextInt(10);
            if (flag % 2 == 0 && !ioFinished) {
                process.requestIO();
            }
            if (flag % 2 == 1 && !computingFinished) {
                for (int i = 0; i < maxComputingStep; i++) {
                    if (!process.getComputingFinished()) {
                        process.compute();
                    }
                }
                if (!checkFinished()) {
                    System.out.println(process.getInfo() + " takes all its CPU time. Its state will switch from Running to Ready.");
                    pcb.setProcessState(ProcessState.READY);
                    OperatingSystemApplication.MAIN_MEMORY.addProcessControlBlock(pcb);
                }
            }
            if (flag % 2 == 0 && ioFinished) {
                if (!computingFinished) {
                    for (int i = 0; i < maxComputingStep; i++) {
                        if (!process.getComputingFinished()) {
                            process.compute();
                        }
                    }
                    if (!checkFinished()) {
                        pcb.setProcessState(ProcessState.READY);
                        OperatingSystemApplication.MAIN_MEMORY.addProcessControlBlock(pcb);
                    }
                }
            }
            if (flag % 2 == 1 && computingFinished) {
                if (!ioFinished) {
                    process.requestIO();
                }
            }
            if (checkFinished()) {
                pcb.setProcessState(ProcessState.TERMINATED);
                System.out.println(process.getInfo() + " has finished all its IO and Computing tasks. Its state switches from Running to Terminated. " +
                        "It will be removed from memory.");
                if (OperatingSystemApplication.MAIN_MEMORY.contains(pcb)) {
                    OperatingSystemApplication.MAIN_MEMORY.removeProcess(pcb);
                }
                OperatingSystemApplication.SECONDARY_MEMORY.removeProcess(pcb);
                longTermScheduler.schedule();
                pcb = null;
            } else {
                pcb = null;
            }
        }
    }

    public boolean checkFinished() {
        Process process = pcb.getProcess();
        boolean ioFinished = process.getIOFinished();
        boolean computingFinished = process.getComputingFinished();
        return ioFinished && computingFinished;
    }

    @Override
    public void run() {
        while (!OperatingSystemApplication.isDone()) {
            shortTermScheduler.schedule();
            process();
            System.out.println(OperatingSystemApplication.MAIN_MEMORY.getInfo());
            System.out.println(OperatingSystemApplication.SECONDARY_MEMORY.getInfo());
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println();
        }
        System.out.println("Tommy Operating System Demo is done. Bye!");
    }

    public void start() {
        System.out.println("CPU is running!");
        shortTermScheduler.setCpu(this);
        longTermScheduler.setCpu(this);
        Thread thread = new Thread(this);
        thread.start();
    }
}
