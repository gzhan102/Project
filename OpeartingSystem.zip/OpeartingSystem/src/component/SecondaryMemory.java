package component;

import process.ProcessState;
import process.pcb.ProcessControlBlock;
import structure.GeneralQueue;
import structure.Iterator;
import structure.Queue;

public class SecondaryMemory {
    private Queue<ProcessControlBlock> jobQueue = new GeneralQueue<>();

    public Queue<ProcessControlBlock> getJobQueue() {
        return jobQueue;
    }

    public void addProcess(ProcessControlBlock pcb) {
        jobQueue.enqueue(pcb);
    }

    public ProcessControlBlock getProcess() {
        Iterator<ProcessControlBlock> iterator = jobQueue.iterator();
        while (iterator.hasNext()) {
            ProcessControlBlock pcb = iterator.next();
            if (pcb.getProcessState() == ProcessState.NEW) {
                return pcb;
            }
        }
        return null;
    }

    public void removeProcess(ProcessControlBlock pcb) {
        jobQueue.remove(pcb);
    }

    public boolean isEmpty() {
        return jobQueue.isEmpty();
    }

    public boolean contains(ProcessControlBlock pcb) {
        return jobQueue.contains(pcb);
    }

    public String getInfo() {
        if (jobQueue.isEmpty()) {
            return "Job Queue is Empty!";
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Job Queue: head -> {");
        Iterator<ProcessControlBlock> iterator = jobQueue.iterator();
        while (iterator.hasNext()) {
            stringBuilder.append(iterator.next().getProcess().getInfo());
            stringBuilder.append(", ");
        }
        stringBuilder.delete(stringBuilder.length() - 2, stringBuilder.length());
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}
