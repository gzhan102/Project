package component;

import app.OperatingSystemApplication;
import process.Process;
import process.ProcessState;
import process.pcb.ProcessControlBlock;
import structure.GeneralQueue;
import structure.Queue;

public class IODevice {
    private Queue<ProcessControlBlock> ioQueue = new GeneralQueue<>();

    public void processIORequest(ProcessControlBlock pcb, long millisec) {
        ioQueue.enqueue(pcb);
        ProcessControlBlock currentPcb = ioQueue.dequeue();
        int ioStep = currentPcb.getCpuState().getIoStep();
        Process process = currentPcb.getProcess();
        try {
            System.out.println(process.getInfo() + " is waiting for I/O. Its state will switch from Running to Waiting.");
            currentPcb.setProcessState(ProcessState.WAITING);
            System.out.println(process.getInfo() + " is doing its " + ioStep + " I/O operation, "
                + " which waits for " + millisec + " millisecond. Its state will switch from Waiting to Ready.");
            Thread.sleep(millisec);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            ioStep++;
            currentPcb.getCpuState().setIoStep(ioStep);
            if (ioStep > process.getMaxIOTasks()) {
                System.out.println(process.getInfo() + " has finished all its I/O operations!");
                process.setIoFinished(true);
            }
            currentPcb.setProcessState(ProcessState.READY);
            //After IO finished, put this pcb back to ready queue.
            OperatingSystemApplication.MAIN_MEMORY.addProcessControlBlock(currentPcb);
        }
    }
}
