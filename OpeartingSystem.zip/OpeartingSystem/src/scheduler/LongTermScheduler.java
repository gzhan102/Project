package scheduler;

import app.OperatingSystemApplication;
import component.CPU;
import component.MainMemory;
import component.SecondaryMemory;
import process.ProcessState;
import process.pcb.ProcessControlBlock;

public class LongTermScheduler implements Scheduler {
    private CPU cpu;
    private static SecondaryMemory SECONDARY_MEMORY = OperatingSystemApplication.SECONDARY_MEMORY;
    private static MainMemory MAIN_MEMORY = OperatingSystemApplication.MAIN_MEMORY;

    public LongTermScheduler() {
        System.out.println("Long-term Scheduler is running!");
    }

    public void setCpu(CPU cpu) {
        this.cpu = cpu;
    }

    @Override
    public void schedule() {
        if (!SECONDARY_MEMORY.isEmpty()) {
            ProcessControlBlock pcb = SECONDARY_MEMORY.getProcess();
            if (pcb == null) {
                System.out.println("There is no more process with NEW state in the secondary memory.");
                return;
            }
            System.out.println("Long-term scheduler puts " + pcb.getProcess().getInfo() + " from secondary memory to main memory. Its state will switch from New to Ready.");
            pcb.setProcessState(ProcessState.READY);
            MAIN_MEMORY.addProcessControlBlock(pcb);
        }
    }
}
