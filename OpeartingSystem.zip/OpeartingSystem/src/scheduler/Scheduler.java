package scheduler;

public interface Scheduler {
    public void schedule();
}
