package scheduler;

import app.OperatingSystemApplication;
import component.CPU;
import component.MainMemory;
import process.ProcessState;
import process.pcb.ProcessControlBlock;

public class ShortTermScheduler implements Scheduler {
    private CPU cpu;
    private static MainMemory MAIN_MEMORY = OperatingSystemApplication.MAIN_MEMORY;

    public ShortTermScheduler() {
        System.out.println("Short-term Scheduler is running!");
    }

    public void setCpu(CPU cpu) {
        this.cpu = cpu;
    }

    @Override
    public void schedule() {
        //Everytime when CPU is idle, the short-term scheduler select a pcb from main memory to CPU.
        if (cpu.getPcb() == null) {
            ProcessControlBlock pcb = MAIN_MEMORY.removeProcessControlBlock();
            System.out.println("Short-term scheduler puts " + pcb.getProcess().getInfo() + " to CPU. Its state will switch from Ready to Running.");
            pcb.setProcessState(ProcessState.RUNNING);
            cpu.setPcb(pcb);
        }
    }
}
