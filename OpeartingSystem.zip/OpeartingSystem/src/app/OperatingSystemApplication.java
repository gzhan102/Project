package app;

import component.CPU;
import component.IODevice;
import component.MainMemory;
import component.SecondaryMemory;
import process.Process;
import process.ProcessType;

import java.util.LinkedList;
import java.util.List;

public class OperatingSystemApplication {
    public static IODevice IO_DEVICE = new IODevice();
    public static MainMemory MAIN_MEMORY = new MainMemory();
    public static SecondaryMemory SECONDARY_MEMORY = new SecondaryMemory();
    public static CPU CPU = new CPU();

    public static void main(String[] args) {
        System.out.println("Tommy Operating System Demo is starting!!!");
        List<Process> processes = new LinkedList<>();
        Process p1 = new Process("one", ProcessType.IOBound);
        Process p2 = new Process("two", ProcessType.CPUBound);
        Process p3 = new Process("three", ProcessType.IOBound);
        Process p4 = new Process("four", ProcessType.CPUBound);
        Process p5 = new Process("five", ProcessType.IOBound);
        processes.add(p1);
        processes.add(p2);
        processes.add(p3);
        processes.add(p4);
        processes.add(p5);
        SECONDARY_MEMORY.addProcess(p1.getPcb());
        SECONDARY_MEMORY.addProcess(p2.getPcb());
        SECONDARY_MEMORY.addProcess(p3.getPcb());
        SECONDARY_MEMORY.addProcess(p4.getPcb());
        SECONDARY_MEMORY.addProcess(p5.getPcb());

        MAIN_MEMORY.addProcessControlBlock(p1.getPcb());
        MAIN_MEMORY.addProcessControlBlock(p2.getPcb());
        MAIN_MEMORY.addProcessControlBlock(p3.getPcb());
        System.out.println("There are all the processes!");
        for (Process process : processes) {
            System.out.println(process);
        }
        System.out.println();
        System.out.println(MAIN_MEMORY.getInfo());
        System.out.println(SECONDARY_MEMORY.getInfo());
        System.out.println();
        CPU.start();
        System.out.println("---------------------------------------------------------------------------------------------");
        System.out.println();
        System.out.println();
    }

    public static boolean isDone() {
        return SECONDARY_MEMORY.isEmpty();
    }
}
