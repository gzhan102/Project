package process;

public enum  ProcessType {
    IOBound,
    CPUBound;
}
