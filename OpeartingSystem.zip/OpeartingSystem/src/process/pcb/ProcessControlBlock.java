package process.pcb;

import process.Process;
import process.ProcessState;

public class ProcessControlBlock {
    private Process process;
    private ProcessState processState;
    private AccountingInfo accountingInfo;
    private CPUState cpuState;

    public ProcessControlBlock(Process process) {
        this.process = process;
        this.processState = process.getState();
        this.accountingInfo = new AccountingInfo(0);
        this.cpuState = new CPUState();
    }

    public void setProcessState(ProcessState processState) {
        this.processState = processState;
        this.process.setState(processState);
    }

    public void setAccountingInfo(AccountingInfo accountingInfo) {
        this.accountingInfo = accountingInfo;
    }

    public void setCpuState(CPUState cpuState) {
        this.cpuState = cpuState;
    }

    public ProcessState getProcessState() {
        return processState;
    }

    public AccountingInfo getAccountingInfo() {
        return accountingInfo;
    }

    public CPUState getCpuState() {
        return cpuState;
    }

    public Process getProcess() {
        return process;
    }

    @Override
    public String toString() {
        return "ProcessControlBlock{" +
                "process=" + process +
                '}';
    }
}
