package process.pcb;

public class CPUState {
    /*
    The current step of the current process.
    Each step takes one cpuTime.
     */
    private int computingStep;

    private int ioStep;

    public CPUState() {
        this.computingStep = 1;
        this.ioStep = 1;
    }

    public void setComputingStep(int computingStep) {
        this.computingStep = computingStep;
    }

    public void setIoStep(int ioStep) {
        this.ioStep = ioStep;
    }

    public int getComputingStep() {
        return computingStep;
    }

    public int getIoStep() {
        return ioStep;
    }
}
