package process.pcb;

public class AccountingInfo {
    /*
    Each process can run at most 2 cpuTime in CPU.
    After 2 cpuTime, the process state will switch from running to ready.
    But in this simple demo, I control it in the CPU manually.
    So for now, this class is useless.
     */
    private int cpuTime;

    public AccountingInfo(int cpuTime) {
        this.cpuTime = cpuTime;
    }

    public void setCPUTime(int CPUTime) {
        this.cpuTime = CPUTime;
    }

    public int getCPUTime() {
        return cpuTime;
    }
}
