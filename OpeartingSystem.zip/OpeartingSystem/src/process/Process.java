package process;

import app.OperatingSystemApplication;
import process.pcb.ProcessControlBlock;

import java.util.Random;

public class Process {
    private String name;
    private ProcessType type;
    private ProcessState state;
    private ProcessControlBlock pcb;
    private int maxComputeTasks;
    private int maxIOTasks;
    private boolean computingFinished;
    private boolean ioFinished;
    private Random random = new Random();

    public Process(String name, ProcessType type) {
        this.name = name;
        this.type = type;
        this.state = ProcessState.NEW;
        if (type == ProcessType.IOBound) {
            //3-5 I/O tasks
            maxIOTasks = 3 + random.nextInt(3);
            //4-6 compute tasks
            maxComputeTasks = 4 + random.nextInt(3);
        } else {
            //1-2 I/O tasks
            maxIOTasks = 1 + random.nextInt(2);
            //8-12 compute tasks
            maxComputeTasks = 8 + random.nextInt(5);
        }
        computingFinished = false;
        ioFinished = false;

        pcb = new ProcessControlBlock(this);
    }

    public void setState(ProcessState state) {
        this.state = state;
    }

    public void setIoFinished(boolean ioFinished) {
        this.ioFinished = ioFinished;
    }

    public ProcessState getState() {
        return state;
    }

    public String getName() {
        return name;
    }

    public boolean getIOFinished() {
        return ioFinished;
    }

    public boolean getComputingFinished() {
        return computingFinished;
    }

    public ProcessControlBlock getPcb() {
        return pcb;
    }

    public int getMaxIOTasks() {
        return maxIOTasks;
    }

    public void requestIO() {
        //Let's assume each I/O process takes 8000-15000 milliseconds.
        long millisec = 8000 + random.nextInt(7001);
        OperatingSystemApplication.IO_DEVICE.processIORequest(pcb, millisec);
    }

    public void compute() {
        int computingStep = pcb.getCpuState().getComputingStep();
        pcb.setProcessState(ProcessState.RUNNING);
        if (computingStep == maxComputeTasks) {
            System.out.println(getInfo() + " has finished all its computing tasks!");
            computingFinished = true;
            return;
        }
        //Let's assume each I/O process takes 3000-8000 milliseconds.
        long millisec = 3000 + random.nextInt(5001);
        System.out.println(getInfo() + " is doing its computing step " + computingStep + " which takes " + millisec + " milliseconds.");
        computingStep++;
        pcb.getCpuState().setComputingStep(computingStep);
        try {
            Thread.sleep(millisec);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public String toString() {
        return "Process{" +
                "name='" + name + '\'' +
                ", type=" + type +
                ", maxComputeTasks=" + maxComputeTasks +
                ", maxIOTasks=" + maxIOTasks +
                ", computingFinished=" + computingFinished +
                ", ioFinished=" + ioFinished +
                '}';
    }

    public String getInfo() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Process{");
        stringBuilder.append(name);
        stringBuilder.append(", state: ");
        stringBuilder.append(state);
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}
