package structure;

public interface Queue<T> {
    public boolean enqueue(T elem);
    public T dequeue();
    public boolean remove(T elem);
    public T peek();
    public boolean isEmpty();
    public boolean isFull();
    public boolean contains(T elem);
    public String toString();
    public int size();
    public Iterator<T> iterator();
}
