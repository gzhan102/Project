package structure;

public class GeneralQueue<T> implements Queue<T> {

    private class Node<E> {
        E elem;
        Node<E> prev;
        Node<E> next;

        public Node(E elem, Node<E> prev, Node<E> next) {
            this.elem = elem;
            this.prev = prev;
            this.next = next;
        }
    }

    private Node<T> head;
    private Node<T> tail;
    private int maxSize;
    private int currentSize;
    private static final int DEFAULT_SIZE = 100;

    public GeneralQueue(int maxSize) {
        this.maxSize = maxSize;
        this.currentSize = 0;
    }

    public GeneralQueue() {
        this.maxSize = DEFAULT_SIZE;
        this.currentSize = 0;
    }

    @Override
    public boolean enqueue(T elem) {
        if (isFull()) {
            return false;
        }
        Node<T> newNode = new Node<>(elem, null, null);
        if (isEmpty()) {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
        currentSize++;
        return true;
    }

    @Override
    public T dequeue() {
        if (isEmpty()) {
            return null;
        }
        Node<T> saved = head;
        currentSize--;
        if (head == tail) {
            head = null;
            tail = null;
            return saved.elem;
        }
        head = saved.next;
        saved.next = null;
        head.prev = null;
        return saved.elem;
    }

    @Override
    public boolean remove(T elem) {
        if (isEmpty()) {
            return false;
        }
        if (!contains(elem)) {
            throw new IllegalStateException("The element doesn't exist");
        }
        if (head.elem == elem) {
            dequeue();
            return true;
        }
        currentSize--;
        Node<T> current = head;
        while (current.elem != elem && current.next != null) {
            current = current.next;
        }
        Node<T> left = current.prev;
        Node<T> right = current.next;
        if (current == tail) {
            left.next = null;
            current.prev = null;
            tail = left;

            return true;
        }
        left.next = right;
        right.prev = left;
        current.prev = null;
        current.next = null;
        return true;
    }

    @Override
    public T peek() {
        return head.elem;
    }

    @Override
    public boolean isEmpty() {
        return currentSize == 0;
    }

    public boolean isFull() {
        return currentSize == maxSize;
    }

    @Override
    public boolean contains(T elem) {
        if (isEmpty()) {
            return false;
        }
        Node<T> current = head;
        while (current != null) {
            if (current.elem == elem) {
                return true;
            }
            current = current.next;
        }
        return false;
    }

    @Override
    public String toString() {
        if (isEmpty()) {
            return "Empty Queue";
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Head -> (");
        Node<T> current = head;
        while (current.next != null) {
            stringBuilder.append(current.elem.toString());
            stringBuilder.append(", ");
            current = current.next;
        }
        stringBuilder.append(current.elem.toString());
        stringBuilder.append(") <- Tail");
        return stringBuilder.toString();
    }

    @Override
    public int size() {
        return currentSize;
    }

    @Override
    public Iterator<T> iterator() {
        return new Iterator<T>() {
            Node<T> current = null;
            @Override
            public boolean hasNext() {
                if (current == null && head == null) {
                    return false;
                } else if (current == null && head != null) {
                    return true;
                }
                return current.next != null;
            }

            @Override
            public T next() {
                if (current == null) {
                    current = head;
                } else {
                    current = current.next;
                }
                return current.elem;
            }
        };
    }
}
